import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HiringReport {

    public static List<String> getHiresBetween(Connection conn, Date start, Date end) throws SQLException {
        String sql = """
            SELECT first_name, last_name, hire_date
            FROM employees
            WHERE hire_date BETWEEN ? AND ?
            ORDER BY hire_date DESC
        """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, start);
            ps.setDate(2, end);
            ResultSet rs = ps.executeQuery();

            List<String> results = new ArrayList<>();

            while (rs.next()) {
                String date = rs.getDate("hire_date").toString();
                String name = rs.getString("first_name") + " " + rs.getString("last_name");

                // Format: date|name
                results.add(date + "|" + name);
            }

            return results;
        }
    }
}
