import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PayStatementReport {

    public static List<String> getPayHistory(Connection conn, int employeeId) throws SQLException {
        String sql = """
            SELECT period_start, period_end, pay_date, gross_pay, taxes, deductions, net_pay
            FROM pay_statements
            WHERE employee_id = ?
            ORDER BY pay_date DESC
        """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();

            List<String> results = new ArrayList<>();

            while (rs.next()) {
                String line = String.format(
                    "Pay Date: %s | Period: %s - %s | Gross: %.2f | Net: %.2f",
                    rs.getDate("pay_date"),
                    rs.getDate("period_start"),
                    rs.getDate("period_end"),
                    rs.getDouble("gross_pay"),
                    rs.getDouble("net_pay")
                );
                results.add(line);
            }
            return results;
        }
    }
}
