import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TotalPayReports {

    public static List<String> payByJobTitle(Connection conn) throws SQLException {
        String sql =
            "SELECT yyyy_mm, job_title, total_gross_pay " +
            "FROM v_monthly_total_pay_by_job_title " +
            "ORDER BY yyyy_mm DESC, job_title ASC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<String> result = new ArrayList<>();

            while (rs.next()) {
                String month = rs.getString("yyyy_mm");
                String title = rs.getString("job_title");
                double total = rs.getDouble("total_gross_pay");

                result.add(month + "|" + title + "|" + total);
            }
            return result;
        }
    }

    public static List<String> payByDivision(Connection conn) throws SQLException {
        String sql =
            "SELECT yyyy_mm, division_name, total_gross_pay " +
            "FROM v_monthly_total_pay_by_division " +
            "ORDER BY yyyy_mm DESC, division_name ASC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<String> result = new ArrayList<>();

            while (rs.next()) {
                String month = rs.getString("yyyy_mm");
                String division = rs.getString("division_name");
                double total = rs.getDouble("total_gross_pay");

                result.add(month + "|" + division + "|" + total);
            }
            return result;
        }
    }
}
