import java.sql.Connection;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AuthService auth = new AuthService();

        System.out.println("=== Company Z Employee Management System ===");

        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        User user = auth.login(username, password);

        if (user == null) {
            System.out.println("Login failed.");
            return;
        }

        System.out.println("\nWelcome, " + user.getUsername());
        System.out.println("Role: " + user.getRole());

        if (user.getRole().equalsIgnoreCase("HR_ADMIN")) {
            hrAdminMenu(scanner, user);
        } else if (user.getRole().equalsIgnoreCase("EMPLOYEE")) {
            employeeMenu(scanner, user);
        } else {
            System.out.println("Unknown role.");
        }

        scanner.close();
    }

    private static void hrAdminMenu(Scanner scanner, User user) {
        while (true) {
            System.out.println("\n=== HR Admin Menu ===");
            System.out.println("1. Search Employee");
            System.out.println("2. Update Employee Info");
            System.out.println("3. Apply Salary Increase");
            System.out.println("4. Report: Pay by Job Title");
            System.out.println("5. Report: Pay by Division");
            System.out.println("6. Report: Employees Hired in Date Range");
            System.out.println("0. Logout");

            System.out.print("Select option: ");
            String choice = scanner.nextLine();

            try (Connection conn = DBConnection.getConnection()) {
                switch (choice) {

                    case "1" -> searchEmployeeMenu(scanner, conn, user);

                    case "2" -> updateEmployeeInfo(scanner, conn, user);

                    case "3" -> SalaryIncreaseRange.main(null);

                    case "4" -> {
                        List<String> list = TotalPayReports.payByJobTitle(conn);
                        if (list.isEmpty()) System.out.println("No data.");
                        else printReportJobTitle(list);
                    }

                    case "5" -> {
                        List<String> list = TotalPayReports.payByDivision(conn);
                        if (list.isEmpty()) System.out.println("No data.");
                        else printReportDivision(list);
                    }

                    case "6" -> {
                        System.out.print("Start date (YYYY-MM-DD): ");
                        Date start = Date.valueOf(scanner.nextLine());
                        System.out.print("End date (YYYY-MM-DD): ");
                        Date end = Date.valueOf(scanner.nextLine());

                        List<String> hires = HiringReport.getHiresBetween(conn, start, end);
                        if (hires.isEmpty()) System.out.println("No hires in this range.");
                        else printReportHires(hires);
                    }

                    case "0" -> {
                        System.out.println("Logging out...");
                        return;
                    }

                    default -> System.out.println("Invalid option.");
                }

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void searchEmployeeMenu(Scanner scanner, Connection conn, User user) throws Exception {
        CompanyZSearch.SearchCriteria sc = new CompanyZSearch.SearchCriteria();

        System.out.println("\nSearch By:");
        System.out.println("1. Last Name");
        System.out.println("2. Employee ID");
        System.out.println("3. Employee Number");
        System.out.println("4. Date of Birth");
        System.out.println("5. SSN Last 4");
        System.out.print("Choose: ");

        String opt = scanner.nextLine();

        switch (opt) {
            case "1" -> {
                System.out.print("Last name fragment: ");
                sc.nameLike = scanner.nextLine();
            }
            case "2" -> {
                System.out.print("Employee ID: ");
                sc.employeeId = Integer.parseInt(scanner.nextLine());
            }
            case "3" -> {
                System.out.print("Employee Number: ");
                sc.empNumber = scanner.nextLine();
            }
            case "4" -> {
                System.out.print("DOB (YYYY-MM-DD): ");
                sc.dob = Date.valueOf(scanner.nextLine()).toLocalDate();
            }
            case "5" -> {
                System.out.print("SSN Last 4: ");
                sc.ssnLast4 = scanner.nextLine();
            }
            default -> {
                System.out.println("Invalid choice.");
                return;
            }
        }

        var results = CompanyZSearch.hrSearchForEdit(conn, user.getUserId(), sc);

        if (results.isEmpty()) {
            System.out.println("No employees found.");
            return;
        }

        System.out.println("\n=== Search Results ===");
        for (int i = 0; i < results.size(); i++) {
            var r = results.get(i);
            System.out.println((i + 1) + ". " + r.firstName + " " + r.lastName +
                    " (ID: " + r.employeeId + ", " + r.empNumber + ")");
        }

        System.out.print("\nSelect employee: ");
        int sel = Integer.parseInt(scanner.nextLine());

        if (sel < 1 || sel > results.size()) {
            System.out.println("Invalid selection.");
            return;
        }

        var chosen = results.get(sel - 1);
        printEmployeeEditRow(chosen);
    }

    private static CompanyZSearch.EmployeeEditRow getEmployeeById(Connection conn, int empId, int userId) throws Exception {
        CompanyZSearch.SearchCriteria sc = new CompanyZSearch.SearchCriteria();
        sc.employeeId = empId;

        var list = CompanyZSearch.hrSearchForEdit(conn, userId, sc);
        return list.isEmpty() ? null : list.get(0);
    }

    private static void updateEmployeeInfo(Scanner scanner, Connection conn, User user) throws Exception {
        System.out.print("Enter Employee ID: ");
        int empId = Integer.parseInt(scanner.nextLine());

        var emp = getEmployeeById(conn, empId, user.getUserId());
        if (emp == null) {
            System.out.println("Employee not found.");
            return;
        }

        printEmployeeEditRow(emp);

        EmployeeUpdateDTO dto = new EmployeeUpdateDTO();
        dto.setEmployeeId(empId);
        dto.setFirstName(emp.firstName);
        dto.setLastName(emp.lastName);
        dto.setEmail(emp.email);
        dto.setPhone(emp.phone);
        dto.setAddress1(emp.address1);
        dto.setAddress2(emp.address2);
        dto.setCity(emp.city);
        dto.setState(emp.stateProvince);
        dto.setPostal(emp.postal);
        dto.setCountry(emp.country);
        dto.setDivisionId(emp.divisionId);
        dto.setJobTitleId(emp.jobTitleId);
        dto.setManagerEmployeeId(emp.managerEmployeeId);

        boolean running = true;

        while (running) {
            System.out.println("\nUpdate:");
            System.out.println("1. First Name");
            System.out.println("2. Last Name");
            System.out.println("3. Email");
            System.out.println("4. Phone");
            System.out.println("5. Address");
            System.out.println("6. Division");
            System.out.println("7. Job Title");
            System.out.println("8. Manager");
            System.out.println("0. Save and Finish");

            System.out.print("Choose: ");
            String c = scanner.nextLine();

            switch (c) {
                case "1" -> {
                    System.out.println("Current First Name: " + dto.getFirstName());
                    System.out.print("New First Name (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setFirstName(nv);
                }

                case "2" -> {
                    System.out.println("Current Last Name: " + dto.getLastName());
                    System.out.print("New Last Name (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setLastName(nv);
                }

                case "3" -> {
                    System.out.println("Current Email: " + dto.getEmail());
                    System.out.print("New Email (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setEmail(nv);
                }

                case "4" -> {
                    System.out.println("Current Phone: " + dto.getPhone());
                    System.out.print("New Phone (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setPhone(nv);
                }

                case "5" -> updateAddressSubMenu(scanner, dto);

                case "6" -> {
                    System.out.println("Current Division ID: " + dto.getDivisionId());
                    System.out.print("New Division ID (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setDivisionId(Integer.parseInt(nv));
                }

                case "7" -> {
                    System.out.println("Current Job Title ID: " + dto.getJobTitleId());
                    System.out.print("New Job Title ID (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setJobTitleId(Integer.parseInt(nv));
                }

                case "8" -> {
                    System.out.println("Current Manager ID: " + dto.getManagerEmployeeId());
                    System.out.print("New Manager ID (blank=keep, 'none'=remove): ");
                    String nv = scanner.nextLine();

                    if (nv.isBlank()) {
                        // keep
                    } else if (nv.equalsIgnoreCase("none")) {
                        dto.setManagerEmployeeId(null);
                    } else {
                        dto.setManagerEmployeeId(Integer.parseInt(nv));
                    }
                }

                case "0" -> running = false;

                default -> System.out.println("Invalid option.");
            }
        }

        EmployeeDAO dao = new EmployeeDAO();
        dao.updateEmployeeBasic(dto, user.getUserId());

        System.out.println("Employee updated.");
    }

    private static void updateAddressSubMenu(Scanner scanner, EmployeeUpdateDTO dto) {
        boolean addr = true;

        while (addr) {
            System.out.println("\nAddress Menu:");
            System.out.println("1. Address Line 1");
            System.out.println("2. Address Line 2");
            System.out.println("3. City");
            System.out.println("4. State");
            System.out.println("5. Postal Code");
            System.out.println("6. Country");
            System.out.println("0. Back");

            System.out.print("Choose: ");
            String a = scanner.nextLine();

            switch (a) {
                case "1" -> {
                    System.out.println("Current Address1: " + dto.getAddress1());
                    System.out.print("New Address1 (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setAddress1(nv);
                }

                case "2" -> {
                    System.out.println("Current Address2: " + dto.getAddress2());
                    System.out.print("New Address2 (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setAddress2(nv);
                }

                case "3" -> {
                    System.out.println("Current City: " + dto.getCity());
                    System.out.print("New City (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setCity(nv);
                }

                case "4" -> {
                    System.out.println("Current State: " + dto.getState());
                    System.out.print("New State (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setState(nv);
                }

                case "5" -> {
                    System.out.println("Current Postal: " + dto.getPostal());
                    System.out.print("New Postal (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setPostal(nv);
                }

                case "6" -> {
                    System.out.println("Current Country: " + dto.getCountry());
                    System.out.print("New Country (blank to keep): ");
                    String nv = scanner.nextLine();
                    if (!nv.isBlank()) dto.setCountry(nv);
                }

                case "0" -> addr = false;

                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void employeeMenu(Scanner scanner, User user) {
        while (true) {
            System.out.println("\n=== Employee Menu ===");
            System.out.println("1. View My Profile");
            System.out.println("2. View My Pay Statements");
            System.out.println("0. Logout");

            System.out.print("Select option: ");
            String c = scanner.nextLine();

            try (Connection conn = DBConnection.getConnection()) {
                switch (c) {
                    case "1" -> {
                        CompanyZSearch.SearchCriteria sc = new CompanyZSearch.SearchCriteria();
                        var row = CompanyZSearch.employeeSearchOwnForView(conn, user.getUserId(), sc);
                        if (row == null) System.out.println("Profile not found.");
                        else printEmployeeProfile(row);
                    }

                    case "2" -> {
                        var list = PayStatementReport.getPayHistory(conn, user.getUserId());
                        if (list.isEmpty()) System.out.println("No pay statements.");
                        else for (String s : list) printPayStatement(s);
                    }

                    case "0" -> {
                        System.out.println("Logging out...");
                        return;
                    }

                    default -> System.out.println("Invalid option.");
                }

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void printEmployeeProfile(CompanyZSearch.EmployeeSelfRow v) {
        System.out.println("\n=== My Profile ===");
        System.out.println("Employee ID: " + v.employeeId);
        System.out.println("Employee Number: " + v.empNumber);
        System.out.println("Name: " + v.firstName + " " + v.lastName);
        System.out.println("DOB: " + v.dob);
        System.out.println("Email: " + v.email);
        System.out.println("Phone: " + v.phone);
        System.out.println("Address1: " + v.address1);
        System.out.println("Address2: " + v.address2);
        System.out.println("City: " + v.city);
        System.out.println("State: " + v.stateProvince);
        System.out.println("Postal: " + v.postal);
        System.out.println("Country: " + v.country);
        System.out.println("Hire Date: " + v.hireDate);
        System.out.println("Status: " + v.status);
        System.out.println("Division: " + v.divisionName);
        System.out.println("Job Title: " + v.jobTitle);
        System.out.println("SSN: " + v.ssnMasked);
        System.out.println("Current Salary: $" + v.currentSalary);
        System.out.println("Effective Salary Date: " + v.salaryEffectiveDate);
    }

    private static void printPayStatement(String line) {
        String[] p = line.split("\\|");
        System.out.println("\n=== Pay Statement ===");
        System.out.println("Period: " + p[0].replace("Period:", "").trim());
        System.out.println("Pay Date: " + p[1].replace("Pay Date:", "").trim());
        System.out.println("Net Pay: " + p[2].replace("Net Pay:", "").trim());
    }

    private static void printEmployeeEditRow(CompanyZSearch.EmployeeEditRow v) {
        System.out.println("\n=== Employee Record ===");
        System.out.println("Employee ID: " + v.employeeId);
        System.out.println("Employee Number: " + v.empNumber);
        System.out.println("Name: " + v.firstName + " " + v.lastName);
        System.out.println("Division: " + v.divisionName);
        System.out.println("Job Title: " + v.jobTitle);
        System.out.println("Email: " + v.email);
        System.out.println("Phone: " + v.phone);
        System.out.println("Status: " + v.status);
    }


    private static void printReportJobTitle(List<String> list) {
        System.out.println("\n=== Pay by Job Title ===\n");
        System.out.printf("%-12s %-32s %-15s\n", "Month", "Job Title", "Total Pay");
        System.out.println("--------------------------------------------------------------------------");

        for (String line : list) {
            String[] p = line.split("\\|");

            String month = p[0].trim();
            String title = p[1].trim();
            String total = p[2].trim();

            System.out.printf("%-12s %-32s $%-15s\n", month, title, total);
        }
    }


    private static void printReportDivision(List<String> list) {
        System.out.println("\n=== Pay by Division ===\n");
        System.out.printf("%-12s %-32s %-15s\n", "Month", "Division", "Total Pay");
        System.out.println("--------------------------------------------------------------------------");

        for (String line : list) {
            String[] p = line.split("\\|");

            String month = p[0].trim();
            String division = p[1].trim();
            String total = p[2].trim();

            System.out.printf("%-12s %-32s $%-15s\n", month, division, total);
        }
    }


    private static void printReportHires(List<String> list) {
        System.out.println("\n=== Employees Hired in Date Range ===\n");
        System.out.printf("%-15s %-25s\n", "Hire Date", "Employee Name");
        System.out.println("------------------------------------------------------------");

        for (String line : list) {
            String[] p = line.split("\\|");
            String date = p[0].trim();
            String name = p[1].trim();
            System.out.printf("%-15s %-25s\n", date, name);
        }
    }
}
